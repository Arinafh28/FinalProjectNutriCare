package com.example.FinalProject;

public interface RecyclerViewItemClickListener {
    void onItemClick(int position);
}